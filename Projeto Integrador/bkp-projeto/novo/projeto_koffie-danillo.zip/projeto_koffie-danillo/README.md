
![Logo](https://github.com/jsrgodoy/projeto_koffie/blob/main/src/logo_white.png?raw=true)


# Projeto Koffie - Branch Danillo


## Autores

* Danillo - [@Danillosdd](https://www.github.com/Danillosdd)
## Documentação de cores

| Cor               | Hexadecimal                                                |
| ----------------- | ---------------------------------------------------------------- |
| Cor exemplo       | ![#ac9675](https://via.placeholder.com/10/ac9675?text=+) #ac9675 |
| Cor exemplo       | ![#f5eeee](https://via.placeholder.com/10/f5eeee?text=+) #f5eeee |
| Cor exemplo       | ![#2a130a](https://via.placeholder.com/10/2a130a?text=+) #2a130a |
| Cor exemplo       | ![#e4d7ce](https://via.placeholder.com/10/e4d7ce?text=+) #e4d7ce |
| Cor exemplo       | ![#aea393](https://via.placeholder.com/10/aea393?text=+) #aea393 |


## Stack utilizada

**Front-end:** HTML, CSS, JAVASCRIPT

**Back-end:** PHP, MYSQL


## Demonstração


https://jsrgodoy.github.io/projeto_koffie
