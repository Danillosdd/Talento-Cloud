
![Logo](https://github.com/jsrgodoy/projeto_koffie/blob/main/src/logo_white.png?raw=true)


# Projeto Koffie - Branch Danillo


## Autores

* Danillo - [@Danillosdd](https://www.github.com/Danillosdd)
## Documentação de cores

| Cor               | Hexadecimal                                                |
| ----------------- | ---------------------------------------------------------------- |
| Cor exemplo       | ![#0a192f](https://via.placeholder.com/10/0a192f?text=+) #0a192f |
| Cor exemplo       | ![#0a192f](https://via.placeholder.com/10/0a192f?text=+) #f8f8f8 |
| Cor exemplo       | ![#0a192f](https://via.placeholder.com/10/0a192f?text=+) #00b48a |
| Cor exemplo       | ![#0a192f](https://via.placeholder.com/10/0a192f?text=+) #00d1a0 |


## Stack utilizada

**Front-end:** HTML, CSS, JAVASCRIPT

**Back-end:** PHP, MYSQL


## Demonstração


https://danillo.info/projeto_koffie