
![Logo](https://github.com/jsrgodoy/projeto_koffie/blob/main/src/bitmap.png?raw=true)


# Projeto Koffie


## Autores

* Danillo - [@Danillosdd](https://www.github.com/Danillosdd)

* Diego - [@diegodevweb](https://www.github.com/diegodevweb)

* Elvis - [@elvissilva12](https://www.github.com/elvissilva12)

* Jeferson- [@jsrgodoy](https://www.github.com/jsrgodoy)



## Documentação de cores

| Cor               | Hexadecimal                                                |
| ----------------- | ---------------------------------------------------------------- |
| Cor exemplo       | ![#0a192f](https://via.placeholder.com/10/0a192f?text=+) #0a192f |
| Cor exemplo       | ![#0a192f](https://via.placeholder.com/10/0a192f?text=+) #f8f8f8 |
| Cor exemplo       | ![#0a192f](https://via.placeholder.com/10/0a192f?text=+) #00b48a |
| Cor exemplo       | ![#0a192f](https://via.placeholder.com/10/0a192f?text=+) #00d1a0 |


## Stack utilizada

**Front-end:** HTML, CSS, JAVASCRIPT

**Back-end:** PHP, MYSQL


## Demonstração


https://danillo.info/projeto_koffie
